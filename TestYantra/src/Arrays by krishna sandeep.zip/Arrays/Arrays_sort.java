package Arrays;

import java.util.Arrays;

public class Arrays_sort 
{
public static void main(String[] args) 
{
	int []a= {2,1,3,6,4};
	Arrays.sort(a);
	for(int i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
	}
		
	
}
}
